# Changelog
All notable changes to this project will be documented in this file.

## 0.14.0
### Changed
- Consume @twilio/flex-ui@0.14.0

## 0.13.0
### Changed
- Consume @twilio/flex-ui@0.13.0

## 0.12.0
### Changed
- Consume @twilio/flex-ui@0.12.0

## 0.7.0

### Changed
- Project bootstrapped with create-react-app and renamed to flex-ui-sample
- Use @twilio/flex-ui@0.7.0
### Removed
- Sample code
